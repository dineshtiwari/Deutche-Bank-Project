package com.wiley.discovery.models;

public class ShopAddressModel {

	private String shopName;
	private String shopAddressNumber;
	private String shopAddressPostCode;
	private String city;
	private String country;
	private String longitude;
	private String latitude;

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public String getShopAddressNumber() {
		return shopAddressNumber;
	}

	public void setShopAddressNumber(String shopAddressNumber) {
		this.shopAddressNumber = shopAddressNumber;
	}

	public String getShopAddressPostCode() {
		return shopAddressPostCode;
	}

	public void setShopAddressPostCode(String shopAddressPostCode) {
		this.shopAddressPostCode = shopAddressPostCode;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

}

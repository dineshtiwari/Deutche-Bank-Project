package com.wiley.discovery.services;

import com.wiley.discovery.models.ShopAddressModel;

public interface ShopDetailsService {

	public ShopAddressModel saveAddress(ShopAddressModel model);
}

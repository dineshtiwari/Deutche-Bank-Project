package com.wiley.discovery.services;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wiley.discovery.models.LongLatService;
import com.wiley.discovery.models.ShopAddressModel;

@Service
public class ShopDetailsServiceImpl implements ShopDetailsService {

	@Override
	public ShopAddressModel saveAddress(ShopAddressModel model) {
		LongLatService latService =new LongLatService();
		String output=latService.getLongitudeLatitude(convertAdressModelToString(model));
		model.setLatitude(output.split("#")[0]);
		model.setLongitude(output.split("#")[1]);
		
		return model;
	}
    
    
	
	public static void main(String []args) throws JsonProcessingException{
		ShopAddressModel addressModel=new ShopAddressModel();
		addressModel.setCity("New Delhi");
		addressModel.setShopAddressNumber("111");
		addressModel.setShopName("Skylark Building, 60, Nehru Place");
		addressModel.setShopAddressPostCode("110019");
		
		ObjectMapper mapper = new ObjectMapper();

				//Object to JSON in String
		String jsonInString = mapper.writeValueAsString(addressModel);
		System.out.println(jsonInString);
	}
	
	public String convertAdressModelToString(ShopAddressModel addressModel){
	StringBuilder builder=new StringBuilder();
	builder.append(addressModel.getShopAddressNumber()+", ");
	builder.append(addressModel.getShopName()+", ");
	builder.append(addressModel.getCity()+", ");
	builder.append(addressModel.getShopAddressPostCode());
	System.out.println("Adress==>"+builder.toString());
	return builder.toString();
	}
}

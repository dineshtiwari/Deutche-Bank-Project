package com.wiley.discovery.restcontrollers;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.wiley.discovery.models.ShopAddressModel;
import com.wiley.discovery.services.ShopDetailsService;


@RestController
@RequestMapping("/notifyShopAddress")

public class ShopDetailsController {
    private ShopDetailsService shopDetailsService;
   
    private Logger log = LogManager.getLogger(ShopDetailsController.class.getName());

    @Autowired
    public ShopDetailsController(ShopDetailsService shopDetailsService) {
        this.shopDetailsService = shopDetailsService;
        
    }
    
    /**
     * used to handle notify event from client page.
     * 
     * @param allRequestParams
     * @param model
     * @return
     */
    
    @RequestMapping(value = "/saveAddress", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<ShopAddressModel> saveAddress(@RequestBody ShopAddressModel model) {
            log.info("Started>>ShopDetailsController>>saveAddress>>Shop Name: "+model.getShopName()); 
            model=  shopDetailsService.saveAddress(model);
        return new ResponseEntity<>(model, HttpStatus.OK);
    }
}
